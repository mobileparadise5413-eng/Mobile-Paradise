
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const MobileParadiseApp());

const String whatsappNumber = '919238412633';

class Product {
  final String name;
  final int price;
  const Product(this.name, this.price);
}

const products = <Product>[
  Product('iPhone 13', 7000),
  Product('iPhone 14', 8000),
  Product('iPhone 14 Plus', 8000),
  Product('iPhone 15', 9000),
  Product('iPhone 15 Plus', 9000),
  Product('iPhone 16', 10000),
  Product('iPhone 16 E', 11000),
  Product('iPhone 15 Pro', 11000),
  Product('iPhone 15 Pro Max', 12000),
  Product('iPhone 16 Pro', 12000),
  Product('iPhone 16 Pro Max', 13000),
];

class MobileParadiseApp extends StatelessWidget {
  const MobileParadiseApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Mobile Paradise',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF080808),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFFFFC107),
        brightness: Brightness.dark,
      ),
      useMaterial3: true,
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final List<Product> cart = [];

  void addToCart(Product p) {
    setState(() => cart.add(p));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${p.name} cart me add ho gaya')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(onShop: () => setState(() => tab = 1)),
      ProductsTab(onAdd: addToCart),
      CartTab(cart: cart),
      const OrdersTab(),
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('MOBILE PARADISE',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
        centerTitle: true,
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.phone_android), label: 'Mobiles'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  final VoidCallback onShop;
  const HomeTab({super.key, required this.onShop});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Image.asset('assets/logo.png', height: 280, fit: BoxFit.cover),
      ),
      const SizedBox(height: 18),
      const Text('Mobile Paradise',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Shopping • Order • iPhone Offers • All India Delivery',
          style: TextStyle(color: Colors.white70, fontSize: 15)),
      const SizedBox(height: 18),
      FilledButton.icon(
        onPressed: onShop,
        icon: const Icon(Icons.shopping_bag_outlined),
        label: const Text('SHOP NOW'),
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFFFFC107),
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
      const SizedBox(height: 18),
      const InfoCard(icon: Icons.location_on_outlined,
          title: 'Shop Address', text: 'Rohtak, Haryana'),
      const InfoCard(icon: Icons.local_shipping_outlined,
          title: 'Delivery', text: 'All India Delivery'),
      const InfoCard(icon: Icons.verified_outlined,
          title: 'Shopping', text: 'Select product, add to cart and place order'),
    ],
  );
}

class InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const InfoCard({super.key, required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(icon, color: const Color(0xFFFFC107)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(text),
    ),
  );
}

class ProductsTab extends StatelessWidget {
  final void Function(Product) onAdd;
  const ProductsTab({super.key, required this.onAdd});

  @override
  Widget build(BuildContext context) => ListView.separated(
    padding: const EdgeInsets.all(12),
    itemCount: products.length,
    separatorBuilder: (_, __) => const SizedBox(height: 8),
    itemBuilder: (_, i) {
      final p = products[i];
      return Card(
        child: ListTile(
          leading: const CircleAvatar(
            backgroundColor: Color(0xFFFFC107),
            child: Icon(Icons.phone_iphone, color: Colors.black),
          ),
          title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('₹${p.price}'),
          trailing: FilledButton(onPressed: () => onAdd(p), child: const Text('ADD')),
        ),
      );
    },
  );
}

class CartTab extends StatelessWidget {
  final List<Product> cart;
  const CartTab({super.key, required this.cart});

  @override
  Widget build(BuildContext context) {
    final total = cart.fold<int>(0, (sum, p) => sum + p.price);
    if (cart.isEmpty) return const Center(child: Text('Cart abhi khaali hai'));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ...cart.map((p) => ListTile(
          title: Text(p.name),
          trailing: Text('₹${p.price}',
              style: const TextStyle(fontWeight: FontWeight.bold)),
        )),
        const Divider(),
        Text('Total: ₹$total',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => CheckoutPage(cart: cart))),
          icon: const Icon(Icons.shopping_cart_checkout),
          label: const Padding(
            padding: EdgeInsets.all(12),
            child: Text('PLACE ORDER'),
          ),
        ),
      ],
    );
  }
}

class CheckoutPage extends StatefulWidget {
  final List<Product> cart;
  const CheckoutPage({super.key, required this.cart});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  final city = TextEditingController(text: 'Rohtak');
  final state = TextEditingController(text: 'Haryana');

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    address.dispose();
    city.dispose();
    state.dispose();
    super.dispose();
  }

  String buildOrderMessage() {
    final total = widget.cart.fold<int>(0, (s, p) => s + p.price);
    final items = widget.cart.map((p) => '• ${p.name} - ₹${p.price}').join('\n');
    return """Hello Mobile Paradise,

I want to place an order.

Customer: ${name.text.trim()}
Phone: ${phone.text.trim()}
Address: ${address.text.trim()}, ${city.text.trim()}, ${state.text.trim()}

Products:
$items

Total: ₹$total

Please confirm availability, final price, delivery and payment details.""";
  }

  Future<void> placeOrder() async {
    if (!formKey.currentState!.validate()) return;
    if (whatsappNumber.startsWith('REPLACE')) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('WhatsApp number required'),
          content: const Text(
            'Publish karne se pehle main.dart me whatsappNumber ko business WhatsApp number se replace karein.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))
          ],
        ),
      );
      return;
    }

    final uri = Uri.parse(
      'https://wa.me/$whatsappNumber?text=${Uri.encodeComponent(buildOrderMessage())}',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('WhatsApp open nahi ho paya.')),
      );
    }
  }

  InputDecoration decoration(String label, IconData icon) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icon),
    border: const OutlineInputBorder(),
  );

  @override
  Widget build(BuildContext context) {
    final total = widget.cart.fold<int>(0, (s, p) => s + p.price);
    return Scaffold(
      appBar: AppBar(title: const Text('Customer Details')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Order Summary',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...widget.cart.map((p) => Text('${p.name} — ₹${p.price}')),
            const SizedBox(height: 8),
            Text('Total: ₹$total',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextFormField(controller: name,
                decoration: decoration('Full Name', Icons.person_outline),
                validator: (v) => v == null || v.trim().isEmpty ? 'Name bhariye' : null),
            const SizedBox(height: 12),
            TextFormField(controller: phone, keyboardType: TextInputType.phone,
                decoration: decoration('Mobile Number', Icons.phone_outlined),
                validator: (v) => v == null || v.trim().length < 10
                    ? 'Valid mobile number bhariye' : null),
            const SizedBox(height: 12),
            TextFormField(controller: address, maxLines: 3,
                decoration: decoration('Delivery Address', Icons.home_outlined),
                validator: (v) => v == null || v.trim().isEmpty
                    ? 'Address bhariye' : null),
            const SizedBox(height: 12),
            TextFormField(controller: city, decoration: decoration('City', Icons.location_city)),
            const SizedBox(height: 12),
            TextFormField(controller: state, decoration: decoration('State', Icons.map_outlined)),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: placeOrder,
              icon: const Icon(Icons.chat),
              label: const Padding(
                padding: EdgeInsets.all(14),
                child: Text('ORDER ON WHATSAPP'),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'WhatsApp par order details bhejne ke baad final availability, price aur delivery terms confirm karein.',
              style: TextStyle(color: Colors.white60),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class OrdersTab extends StatelessWidget {
  const OrdersTab({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(24),
      child: Text(
        'Order history yahan dikh sakti hai.\n\nCurrent version me order WhatsApp par confirmation ke liye bheja jata hai.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 16, color: Colors.white70),
      ),
    ),
  );
}
