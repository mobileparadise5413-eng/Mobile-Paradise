# Mobile Paradise — Android + iPhone Shopping App

Business:
- Name: Mobile Paradise
- Address: Rohtak, Haryana
- WhatsApp: +91 9238412633

Included:
- Mobile Paradise logo
- Home and product catalogue
- Supplied iPhone price list
- Cart
- Customer name, phone and delivery address checkout
- Order summary
- WhatsApp order handoff to +91 9238412633
- Rohtak, Haryana
- All India Delivery

## Build
Install Flutter + Android Studio:
1. `flutter pub get`
2. `flutter run`
3. Android APK: `flutter build apk --release`
4. Google Play bundle: `flutter build appbundle --release`

For iPhone, use macOS + Xcode:
`flutter build ipa --release`

## Publishing
A Google Play Console developer account and its verification/payment requirements are needed to publish the app. The publisher must complete the Play Console app listing, privacy/data-safety declarations, content rating, app access information, store assets, and release setup.

Before publishing, verify prices, stock, product condition/warranty, delivery terms, payment method and business contact details.
